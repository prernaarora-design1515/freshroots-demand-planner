/**
 * Raghav's demand-planning rules, as documented in the Freshroots brief.
 * Deterministic and side-effect free: the numbers come from here, never from the LLM.
 *
 * Decisions agreed for this build:
 *  - 12-week average INCLUDES the latest 4 weeks (latest 12 weeks of sales).
 *  - The 25% festival uplift applies to expected weekly demand, i.e. only the
 *    weeks-of-cover checks. The high-demand check compares raw sales.
 *  - Festival status is taken from the month of the inventory as-of date
 *    (the month we are planning for), looked up in the calendar.
 *  - Open purchase orders (Zoho drafts/issued POs not yet received, plus any
 *    uploaded open_purchase_orders.csv) are netted off the reorder quantity.
 *    The flags still use stock on hand, as in Raghav's rules: an open PO
 *    doesn't put stock on the shelf until it arrives.
 */

export const RULES = {
  highDemandLift: 0.2, // last 4 wks > 20% above 12-wk avg
  highDemandMultiplier: 1.5, // reorder at 1.5x standard qty
  festivalUplift: 0.25,
  lowPerish: { minWeeks: 6, maxWeeks: 14 },
  highPerish: { minWeeks: 3, maxWeeks: 4 },
  borderlineBand: 0.1, // within 10% of a threshold counts as borderline
  minHistoryWeeks: 12,
  swingPct: 0.3, // a week-on-week change above ±30%...
  swingTransitions: 4, // ...in the last 4 week-to-week moves -> planner review
} as const;

export type Flag = "HIGH_DEMAND" | "STOCKOUT_RISK" | "OVERSTOCK_RISK";
export type Action = "REORDER_NOW" | "REORDER" | "COVERED" | "PAUSE" | "REVIEW" | "NO_ACTION";

export interface SkuInput {
  skuId: string;
  name: string;
  perishability: string; // "Low" | "High"
  standardReorderQty: number;
}

export interface EvaluateInput {
  skus: SkuInput[];
  sales: { skuId: string; week: string; unitsSold: number }[];
  onHand: Record<string, number>;
  isFestival: boolean;
  /** Units already on open or draft purchase orders, per SKU. */
  openPo?: Record<string, number>;
}

export interface SkuResult {
  skuId: string;
  name: string;
  perishability: string;
  avg4: number;
  avg12: number;
  demandLiftPct: number; // e.g. 21.4 means +21.4%
  expectedWeeklyDemand: number;
  weeksOfCover: number;
  minWeeks: number;
  maxWeeks: number;
  onHand: number;
  openPoQty: number;
  coverWithOpenPo: number; // weeks of cover once open POs arrive
  flags: Flag[];
  action: Action;
  grossQty: number; // rules' quantity before netting open POs
  recommendedQty: number; // what to order now = max(0, gross - open POs)
  borderline: string | null;
  needsJudgment: boolean;
  reviewReasons: string[]; // why a planner must look: New launch, Demand swing, Conflicting flags, Missing or invalid data
  ruleSummary: string;
}

const round1 = (n: number) => Math.round(n * 10) / 10;
const mean = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
const near = (value: number, threshold: number) =>
  Math.abs(value - threshold) <= threshold * RULES.borderlineBand;

export function evaluate(input: EvaluateInput): SkuResult[] {
  const byS = new Map<string, { week: string; unitsSold: number }[]>();
  for (const s of input.sales) {
    if (!byS.has(s.skuId)) byS.set(s.skuId, []);
    byS.get(s.skuId)!.push(s);
  }

  return input.skus.map((sku) => {
    const sorted = (byS.get(sku.skuId) ?? []).slice().sort((a, b) => a.week.localeCompare(b.week));
    const history = sorted.map((s) => s.unitsSold);
    const weeks = sorted.map((s) => s.week.slice(5));
    const stockKnown = input.onHand[sku.skuId] !== undefined;
    const onHand = input.onHand[sku.skuId] ?? 0;
    const openPoQty = Math.max(0, Math.round(input.openPo?.[sku.skuId] ?? 0));
    const isHigh = sku.perishability.toLowerCase() === "high";
    const { minWeeks, maxWeeks } = isHigh ? RULES.highPerish : RULES.lowPerish;

    const avg4 = mean(history.slice(-4));
    const avg12 = mean(history.slice(-12));
    const uplift = input.isFestival ? 1 + RULES.festivalUplift : 1;
    const expected = avg12 * uplift;
    const woc = expected > 0 ? onHand / expected : Infinity;
    const wocNoUplift = avg12 > 0 ? onHand / avg12 : Infinity;
    const lift = avg12 > 0 ? avg4 / avg12 - 1 : 0;

    const base = {
      skuId: sku.skuId,
      name: sku.name,
      perishability: sku.perishability,
      avg4: round1(avg4),
      avg12: round1(avg12),
      demandLiftPct: round1(lift * 100),
      expectedWeeklyDemand: round1(expected),
      weeksOfCover: Number.isFinite(woc) ? round1(woc) : 999,
      minWeeks,
      maxWeeks,
      onHand,
      openPoQty,
      coverWithOpenPo: expected > 0 ? round1((onHand + openPoQty) / expected) : 999,
    };

    // Missing or invalid data: never guess. Hold at 0 and ask the planner.
    const dataProblems: string[] = [];
    if (!stockKnown) dataProblems.push("no stock figure in current_inventory");
    if (!["high", "low"].includes(sku.perishability.toLowerCase())) dataProblems.push(`perishability "${sku.perishability}" is not High or Low`);
    if (!(sku.standardReorderQty > 0)) dataProblems.push("standard reorder qty is missing or 0");
    if (!history.length) dataProblems.push("no sales history");
    if (dataProblems.length) {
      return {
        ...base,
        flags: [],
        action: "REVIEW",
        grossQty: 0,
        recommendedQty: 0,
        borderline: null,
        needsJudgment: true,
        reviewReasons: ["Missing or invalid data"],
        ruleSummary: `Data problem: ${dataProblems.join("; ")}. Held at 0 instead of guessing; fix the data or decide manually.`,
      };
    }

    // New launches / thin history: the rules can't be trusted -> Raghav decides.
    if (history.length < RULES.minHistoryWeeks) {
      return {
        ...base,
        flags: [],
        action: "REVIEW",
        grossQty: 0,
        recommendedQty: 0,
        borderline: null,
        needsJudgment: true,
        reviewReasons: ["New launch"],
        ruleSummary:
          `Only ${history.length} week(s) of sales history (rules need ${RULES.minHistoryWeeks}). Treat as a new launch: planner judgment required.` +
          (openPoQty ? ` ${openPoQty} units already on open POs.` : ""),
      };
    }

    const flags: Flag[] = [];
    if (lift > RULES.highDemandLift) flags.push("HIGH_DEMAND");
    if (woc < minWeeks) flags.push("STOCKOUT_RISK");
    if (woc > maxWeeks) flags.push("OVERSTOCK_RISK");

    // Priority when flags combine.
    let action: Action = "NO_ACTION";
    let qty = 0;
    let needsJudgment = false;
    const reviewReasons: string[] = [];
    const std = sku.standardReorderQty;
    const hd = flags.includes("HIGH_DEMAND");
    if (flags.includes("STOCKOUT_RISK")) {
      action = "REORDER_NOW";
      qty = hd ? Math.round(std * RULES.highDemandMultiplier) : std;
    } else if (flags.includes("OVERSTOCK_RISK") && hd) {
      action = "REVIEW"; // demand is rising but stock is high: conflicting signals
      needsJudgment = true;
      reviewReasons.push("Conflicting flags");
    } else if (flags.includes("OVERSTOCK_RISK")) {
      action = "PAUSE";
    } else if (hd) {
      action = "REORDER";
      qty = Math.round(std * RULES.highDemandMultiplier);
    }

    // Deterministic borderline notes (the LLM only rephrases these).
    const notes: string[] = [];
    if (near(lift, RULES.highDemandLift))
      notes.push(`demand lift ${base.demandLiftPct}% is close to the 20% high-demand line`);
    if (near(woc, minWeeks))
      notes.push(`${base.weeksOfCover} weeks of cover is close to the ${minWeeks}-week minimum`);
    if (near(woc, maxWeeks))
      notes.push(`${base.weeksOfCover} weeks of cover is close to the ${maxWeeks}-week maximum`);
    if (input.isFestival) {
      const stockoutNoUplift = wocNoUplift < minWeeks;
      const overNoUplift = wocNoUplift > maxWeeks;
      if (flags.includes("STOCKOUT_RISK") !== stockoutNoUplift)
        notes.push(`stockout flag is caused by the festival uplift (${round1(wocNoUplift)} weeks without it)`);
      if (flags.includes("OVERSTOCK_RISK") !== overNoUplift)
        notes.push(`overstock flag changes with the festival uplift (${round1(wocNoUplift)} weeks without it)`);
    }
    // Unusual swing (stand-in for unusual distributor behaviour: one distributor per SKU).
    const swings: string[] = [];
    for (let i = Math.max(1, history.length - RULES.swingTransitions); i < history.length; i++) {
      const prev = history[i - 1];
      if (prev > 0 && Math.abs(history[i] / prev - 1) > RULES.swingPct)
        swings.push(`${history[i] > prev ? "+" : ""}${Math.round((history[i] / prev - 1) * 100)}% (${weeks[i - 1]}→${weeks[i]})`);
    }
    if (swings.length) {
      needsJudgment = true;
      if (action === "NO_ACTION") action = "REVIEW"; // in range, but the swing needs a human look
      reviewReasons.push("Demand swing");
      notes.push(`weekly sales swung ${swings.join(", ")}: check for a distributor event, scheme or one-off order before approving`);
    }

    // Net open purchase orders off the order quantity.
    const grossQty = qty;
    const ruleAction = action;
    let netQty = qty;
    if (qty > 0 && openPoQty > 0) {
      netQty = Math.max(0, qty - openPoQty);
      if (netQty === 0) action = "COVERED";
    }
    if (action === "PAUSE" && openPoQty > 0)
      notes.push(`${openPoQty} units are still on open POs and would take cover to ${base.coverWithOpenPo} weeks: consider delaying them`);
    const borderline = notes.length ? notes.join("; ") : null;

    return {
      ...base,
      flags,
      action,
      grossQty,
      recommendedQty: netQty,
      borderline,
      needsJudgment,
      reviewReasons,
      ruleSummary:
        summarise(base, flags, ruleAction, grossQty, std, input.isFestival, isHigh) +
        netNote(grossQty, openPoQty, netQty, action, base.coverWithOpenPo),
    };
  });
}

function netNote(gross: number, open: number, net: number, action: Action, coverAfter: number) {
  if (!gross || !open) return "";
  if (action === "COVERED")
    return ` Open POs already cover it (${open} units on order, ${coverAfter} weeks of cover once received): no new order needed.`;
  return ` ${open} units already on open POs, so order ${net} more (${gross} − ${open}).`;
}

function summarise(
  b: { demandLiftPct: number; weeksOfCover: number; minWeeks: number; maxWeeks: number; avg12: number; onHand: number },
  flags: Flag[],
  action: Action,
  qty: number,
  std: number,
  festival: boolean,
  isHigh: boolean,
): string {
  const window = `${b.minWeeks}–${b.maxWeeks} weeks${isHigh ? " (high-perishability)" : ""}`;
  const cover = `${b.onHand} units on hand = ${b.weeksOfCover} weeks of cover${festival ? " incl. 25% festival uplift" : ""}; target ${window}.`;
  const lift = `Last 4 weeks are ${b.demandLiftPct >= 0 ? "+" : ""}${b.demandLiftPct}% vs the 12-week average (${b.avg12}/wk).`;
  switch (action) {
    case "REORDER_NOW":
      return `Stockout risk. ${cover} ${lift} Reorder now: ${qty} units${flags.includes("HIGH_DEMAND") ? ` (1.5× standard ${std}, high demand)` : " (standard qty)"}.`;
    case "REORDER":
      return `High demand. ${lift} ${cover} Reorder ${qty} units (1.5× standard ${std}).`;
    case "PAUSE":
      return `Overstock risk. ${cover} Pause the next order.`;
    case "REVIEW":
      return `Conflicting signals: high demand but overstocked. ${lift} ${cover} Planner judgment required.`;
    default:
      return `Within range. ${cover} ${lift} No action.`;
  }
}
